import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  FlatList,
  TouchableOpacity,
  Image,
  Keyboard
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { getAllNovels } from '../data/novelsData';

export default function SearchScreen({ navigation }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [recentSearches] = useState([
    'إمبراطور السيوف',
    'شيانشيا',
    'رومانسي',
    'مغامرات'
  ]);

  const handleSearch = (query) => {
    setSearchQuery(query);
    if (query.trim()) {
      const allNovels = getAllNovels();
      const results = allNovels.filter(novel =>
        novel.title.toLowerCase().includes(query.toLowerCase()) ||
        novel.author.toLowerCase().includes(query.toLowerCase()) ||
        novel.category.toLowerCase().includes(query.toLowerCase()) ||
        novel.tags.some(tag => tag.toLowerCase().includes(query.toLowerCase()))
      );
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  };

  const renderSearchResult = ({ item }) => (
    <TouchableOpacity
      style={styles.resultItem}
      onPress={() => {
        Keyboard.dismiss();
        navigation.navigate('NovelDetail', { novel: item });
      }}
    >
      <Image source={{ uri: item.cover }} style={styles.resultImage} />
      
      <View style={styles.resultDetails}>
        <Text style={styles.resultTitle} numberOfLines={2}>
          {item.title}
        </Text>
        <Text style={styles.resultAuthor} numberOfLines={1}>
          {item.author}
        </Text>
        
        <View style={styles.resultMeta}>
          <View style={styles.resultMetaItem}>
            <Ionicons name="star" size={12} color="#ffa500" />
            <Text style={styles.resultMetaText}>{item.rating}</Text>
          </View>
          <View style={styles.resultMetaItem}>
            <Ionicons name="book-outline" size={12} color="#666" />
            <Text style={styles.resultMetaText}>{item.chapters}</Text>
          </View>
        </View>
      </View>

      <Ionicons name="chevron-back" size={20} color="#666" />
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="arrow-forward" size={24} color="#fff" />
        </TouchableOpacity>
        
        <View style={styles.searchInputContainer}>
          <Ionicons name="search" size={20} color="#666" />
          <TextInput
            style={styles.searchInput}
            placeholder="ابحث عن رواية، مؤلف، تصنيف..."
            placeholderTextColor="#666"
            value={searchQuery}
            onChangeText={handleSearch}
            autoFocus
          />
          {searchQuery !== '' && (
            <TouchableOpacity onPress={() => handleSearch('')}>
              <Ionicons name="close-circle" size={20} color="#666" />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {searchQuery === '' ? (
        <View style={styles.emptyContainer}>
          <View style={styles.recentSearchesSection}>
            <Text style={styles.sectionTitle}>🔍 عمليات بحث حديثة</Text>
            <View style={styles.recentSearchesList}>
              {recentSearches.map((search, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.recentSearchChip}
                  onPress={() => handleSearch(search)}
                >
                  <Ionicons name="time-outline" size={16} color="#666" />
                  <Text style={styles.recentSearchText}>{search}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <View style={styles.popularSection}>
            <Text style={styles.sectionTitle}>🔥 أكثر البحوث شيوعاً</Text>
            <View style={styles.popularList}>
              {['شيانشيا', 'رومانسي', 'مغامرات', 'انتقام', 'قوة'].map((tag, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.popularChip}
                  onPress={() => handleSearch(tag)}
                >
                  <Text style={styles.popularText}>{tag}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </View>
      ) : searchResults.length > 0 ? (
        <FlatList
          data={searchResults}
          renderItem={renderSearchResult}
          keyExtractor={item => item.id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.resultsList}
        />
      ) : (
        <View style={styles.noResultsContainer}>
          <Ionicons name="search-outline" size={80} color="#2a2a2a" />
          <Text style={styles.noResultsText}>لا توجد نتائج</Text>
          <Text style={styles.noResultsSubtext}>
            جرب البحث بكلمات مفتاحية أخرى
          </Text>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    gap: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#1a1a1a',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#1a1a1a',
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchInputContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
    borderRadius: 15,
    paddingHorizontal: 15,
    height: 48,
    gap: 10,
    borderWidth: 1,
    borderColor: '#2a2a2a',
  },
  searchInput: {
    flex: 1,
    color: '#fff',
    fontSize: 16,
    textAlign: 'right',
  },
  emptyContainer: {
    padding: 20,
  },
  recentSearchesSection: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 15,
    textAlign: 'right',
  },
  recentSearchesList: {
    gap: 10,
  },
  recentSearchChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
    paddingHorizontal: 15,
    paddingVertical: 12,
    borderRadius: 15,
    gap: 10,
    borderWidth: 1,
    borderColor: '#2a2a2a',
  },
  recentSearchText: {
    color: '#aaa',
    fontSize: 15,
    flex: 1,
    textAlign: 'right',
  },
  popularSection: {
    marginTop: 10,
  },
  popularList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  popularChip: {
    backgroundColor: 'rgba(74, 124, 199, 0.2)',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#4a7cc7',
  },
  popularText: {
    color: '#4a7cc7',
    fontSize: 14,
    fontWeight: '600',
  },
  resultsList: {
    padding: 20,
  },
  resultItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
    borderRadius: 15,
    marginBottom: 12,
    padding: 12,
    gap: 12,
    borderWidth: 1,
    borderColor: '#2a2a2a',
  },
  resultImage: {
    width: 70,
    height: 95,
    borderRadius: 10,
    backgroundColor: '#2a2a2a',
  },
  resultDetails: {
    flex: 1,
  },
  resultTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 5,
    textAlign: 'right',
  },
  resultAuthor: {
    fontSize: 13,
    color: '#888',
    marginBottom: 8,
    textAlign: 'right',
  },
  resultMeta: {
    flexDirection: 'row',
    gap: 12,
  },
  resultMetaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  resultMetaText: {
    fontSize: 12,
    color: '#666',
  },
  noResultsContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  noResultsText: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
    marginTop: 20,
    marginBottom: 10,
  },
  noResultsSubtext: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
});