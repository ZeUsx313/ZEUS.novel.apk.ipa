
import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Animated,
  RefreshControl,
  StatusBar
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { novelsData } from '../data/novelsData';
import { useApp } from '../context/AppContext';

// --- Reusable Animated Button ---
const ScaleButton = ({ onPress, style, children }) => {
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handlePressIn = () => {
    Animated.spring(scaleAnim, {
      toValue: 0.95,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.spring(scaleAnim, {
      toValue: 1,
      friction: 3,
      tension: 40,
      useNativeDriver: true,
    }).start();
  };

  return (
    <TouchableOpacity
      activeOpacity={1}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      onPress={onPress}
    >
      <Animated.View style={[style, { transform: [{ scale: scaleAnim }] }]}>
        {children}
      </Animated.View>
    </TouchableOpacity>
  );
};

export default function HomeScreen({ navigation }) {
  const { getLastRead } = useApp();
  const [refreshing, setRefreshing] = useState(false);
  const scrollY = useRef(new Animated.Value(0)).current;
  
  const lastReadItem = getLastRead();
  const featuredNovel = novelsData.trending[0]; 

  const onRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1500);
  };

  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 150],
    outputRange: [0, 1],
    extrapolate: 'clamp',
  });

  const renderSectionHeader = (title, iconName) => (
    <View style={styles.sectionHeader}>
      <TouchableOpacity onPress={() => {}}>
        <Ionicons name="arrow-back" size={20} color="#666" style={{transform: [{rotate: '180deg'}]}} />
      </TouchableOpacity>
      <View style={styles.titleWrapper}>
        <Text style={styles.sectionTitle}>{title}</Text>
        <Ionicons name={iconName} size={18} color="#fff" style={{ marginLeft: 8 }} />
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#000" />
      
      {/* Animated Sticky Header */}
      <Animated.View style={[styles.stickyHeader, { opacity: headerOpacity }]}>
        <SafeAreaView edges={['top']}>
          <View style={styles.headerContent}>
             <TouchableOpacity onPress={() => navigation.navigate('Search')}>
               <Ionicons name="search" size={24} color="#fff" />
             </TouchableOpacity>
             <Text style={styles.headerTitleSticky}>الرئيسية</Text>
             <Ionicons name="notifications-outline" size={24} color="#fff" />
          </View>
        </SafeAreaView>
      </Animated.View>

      <Animated.ScrollView
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: true }
        )}
        scrollEventThrottle={16}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#fff" />
        }
      >
        {/* Hero Section (Featured) */}
        <ScaleButton onPress={() => navigation.navigate('NovelDetail', { novel: featuredNovel })}>
          <View style={styles.heroContainer}>
            <Image source={{ uri: featuredNovel?.cover }} style={styles.heroImage} />
            <LinearGradient
              colors={['transparent', '#000000']}
              style={styles.heroGradient}
            >
              <View style={styles.heroInfo}>
                <View style={styles.tagContainer}>
                  <Text style={styles.tagText}>مميز</Text>
                </View>
                <Text style={styles.heroTitle} numberOfLines={2}>{featuredNovel?.title}</Text>
                <Text style={styles.heroAuthor}>{featuredNovel?.author}</Text>
              </View>
            </LinearGradient>
          </View>
        </ScaleButton>

        {/* Continue Reading Section (Dynamic) */}
        {lastReadItem ? (
          <View style={styles.section}>
            <Text style={styles.sectionTitleSimple}>استئناف القراءة</Text>
            <ScaleButton 
              style={styles.continueCard}
              onPress={() => navigation.navigate('Reader', { 
                novel: lastReadItem.novel, 
                chapterId: lastReadItem.chapterId 
              })}
            >
              <Image source={{ uri: lastReadItem.novel.cover }} style={styles.continueCover} />
              <View style={styles.continueInfo}>
                <Text style={styles.continueTitle}>{lastReadItem.novel.title}</Text>
                <Text style={styles.continueChapter}>الفصل {lastReadItem.chapterId}</Text>
                <View style={styles.progressBarBg}>
                  <View style={[styles.progressBarFill, { width: `${lastReadItem.percentage}%` }]} />
                </View>
                <Text style={styles.progressText}>{lastReadItem.percentage}% مكتمل</Text>
              </View>
              <View style={styles.playIconContainer}>
                 <Ionicons name="play" size={20} color="#000" />
              </View>
            </ScaleButton>
          </View>
        ) : null}

        {/* Trending Section */}
        <View style={styles.section}>
          {renderSectionHeader('الأكثر قراءة', 'flame-outline')}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.horizontalList}>
            {novelsData.trending.map((item, index) => (
              <ScaleButton 
                key={index} 
                style={styles.cardContainer}
                onPress={() => navigation.navigate('NovelDetail', { novel: item })}
              >
                <Image source={{ uri: item.cover }} style={styles.cardImage} />
                <Text style={styles.cardTitle} numberOfLines={2}>{item.title}</Text>
                <View style={styles.cardMeta}>
                  <Ionicons name="star" size={10} color="#fff" />
                  <Text style={styles.cardRating}>{item.rating}</Text>
                </View>
              </ScaleButton>
            ))}
          </ScrollView>
        </View>

        {/* New Arrivals Section */}
        <View style={styles.section}>
          {renderSectionHeader('أضيف حديثاً', 'time-outline')}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.horizontalList}>
            {novelsData.latest.map((item, index) => (
              <ScaleButton 
                key={index} 
                style={styles.cardContainer}
                onPress={() => navigation.navigate('NovelDetail', { novel: item })}
              >
                <Image source={{ uri: item.cover }} style={styles.cardImage} />
                <Text style={styles.cardTitle} numberOfLines={2}>{item.title}</Text>
                <Text style={styles.cardCategory}>{item.category}</Text>
              </ScaleButton>
            ))}
          </ScrollView>
        </View>

        <View style={{ height: 100 }} />
      </Animated.ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  stickyHeader: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0,0,0,0.95)',
    zIndex: 100,
    borderBottomWidth: 1,
    borderBottomColor: '#1A1A1A',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  headerTitleSticky: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  heroContainer: {
    height: 450,
    width: '100%',
    position: 'relative',
  },
  heroImage: {
    width: '100%',
    height: '100%',
    opacity: 0.8,
  },
  heroGradient: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 300,
    justifyContent: 'flex-end',
    padding: 20,
  },
  tagContainer: {
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
    alignSelf: 'flex-end',
    marginBottom: 10,
  },
  tagText: {
    color: '#000',
    fontWeight: 'bold',
    fontSize: 12,
  },
  heroInfo: {
    alignItems: 'flex-end',
  },
  heroTitle: {
    color: '#fff',
    fontSize: 32,
    fontWeight: 'bold',
    textAlign: 'right',
    marginBottom: 5,
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 10,
  },
  heroAuthor: {
    color: '#ccc',
    fontSize: 16,
    textAlign: 'right',
  },
  section: {
    marginTop: 35,
    paddingBottom: 5,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  titleWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  sectionTitle: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
  sectionTitleSimple: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'right',
    marginRight: 20,
    marginBottom: 20,
  },
  horizontalList: {
    paddingRight: 20,
    paddingLeft: 10,
  },
  cardContainer: {
    width: 140,
    marginRight: 15,
  },
  cardImage: {
    width: 140,
    height: 210,
    borderRadius: 8,
    backgroundColor: '#1A1A1A',
    marginBottom: 10,
  },
  cardTitle: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'right',
    marginBottom: 4,
  },
  cardMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 4,
  },
  cardRating: {
    color: '#ccc',
    fontSize: 12,
  },
  cardCategory: {
    color: '#666',
    fontSize: 12,
    textAlign: 'right',
  },
  continueCard: {
    marginHorizontal: 20,
    backgroundColor: '#111',
    borderRadius: 12,
    padding: 15,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#222',
  },
  continueCover: {
    width: 60,
    height: 90,
    borderRadius: 6,
    marginLeft: 15,
  },
  continueInfo: {
    flex: 1,
    alignItems: 'flex-end',
  },
  continueTitle: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  continueChapter: {
    color: '#888',
    fontSize: 13,
    marginBottom: 10,
  },
  progressBarBg: {
    width: '100%',
    height: 4,
    backgroundColor: '#333',
    borderRadius: 2,
    marginBottom: 6,
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: '#fff',
    borderRadius: 2,
  },
  progressText: {
    color: '#666',
    fontSize: 10,
  },
  playIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
});
