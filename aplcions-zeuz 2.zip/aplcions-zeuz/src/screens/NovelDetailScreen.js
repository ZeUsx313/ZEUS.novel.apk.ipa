
import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Animated,
  Dimensions,
  StatusBar
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useApp } from '../context/AppContext';

const { height } = Dimensions.get('window');

// Generate chapter list based on novel ID to simulate realism
const getChapters = (novel) => {
  const count = novel.chapters || 50;
  return Array.from({ length: 50 }, (_, i) => ({
    id: i + 1,
    title: `الفصل ${i + 1}: ${i === 0 ? 'البداية' : 'تطور الأحداث والمواجهة'}`,
    date: 'منذ يومين',
    isRead: false // In real app, check against readingHistory
  }));
};

export default function NovelDetailScreen({ route, navigation }) {
  const { novel } = route.params;
  const { isInLibrary, toggleLibrary, readingHistory } = useApp();
  const [activeTab, setActiveTab] = useState('about'); 
  const scrollY = useRef(new Animated.Value(0)).current;
  
  const inLib = isInLibrary(novel.id);
  const chaptersList = getChapters(novel);
  
  // Check progress
  const progress = readingHistory[novel.id];

  // Header Animation
  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 200],
    outputRange: [0, 1],
    extrapolate: 'clamp',
  });

  const imageScale = scrollY.interpolate({
    inputRange: [-100, 0],
    outputRange: [1.2, 1],
    extrapolate: 'clamp',
  });

  const renderTabButton = (id, title) => (
    <TouchableOpacity 
      style={[styles.tabButton, activeTab === id && styles.tabButtonActive]}
      onPress={() => setActiveTab(id)}
    >
      <Text style={[styles.tabText, activeTab === id && styles.tabTextActive]}>{title}</Text>
    </TouchableOpacity>
  );

  const renderChapterItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.chapterItem}
      onPress={() => navigation.navigate('Reader', { novel, chapterId: item.id })}
    >
      <View style={styles.chapterLeft}>
        <Ionicons 
          name={progress && progress.chapterId >= item.id ? "checkmark-circle" : "ellipse-outline"} 
          size={18} 
          color={progress && progress.chapterId >= item.id ? "#4a7cc7" : "#fff"} 
        />
      </View>
      <View style={styles.chapterContent}>
        <Text style={[styles.chapterTitle, progress && progress.chapterId >= item.id && styles.chapterTitleRead]}>
          {item.title}
        </Text>
        <Text style={styles.chapterDate}>{item.date}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      
      {/* Custom Header */}
      <Animated.View style={[styles.header, { opacity: headerOpacity }]}>
        <SafeAreaView edges={['top']} style={styles.headerSafe}>
          <Text style={styles.headerTitle} numberOfLines={1}>{novel.title}</Text>
        </SafeAreaView>
      </Animated.View>

      {/* Back & Share Buttons (Always Visible) */}
      <SafeAreaView edges={['top']} style={styles.floatingControls}>
        <TouchableOpacity style={styles.iconButton} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.iconButton}>
          <Ionicons name="share-social-outline" size={24} color="#fff" />
        </TouchableOpacity>
      </SafeAreaView>

      <Animated.ScrollView
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: true }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={{ paddingBottom: 100 }}
      >
        {/* Cover Image */}
        <Animated.View style={[styles.coverContainer, { transform: [{ scale: imageScale }] }]}>
          <Image source={{ uri: novel.cover }} style={styles.coverImage} />
          <LinearGradient
            colors={['transparent', '#000000']}
            style={styles.coverGradient}
          />
        </Animated.View>

        {/* Info Container */}
        <View style={styles.contentContainer}>
          <Text style={styles.title}>{novel.title}</Text>
          <Text style={styles.author}>تأليف: {novel.author}</Text>
          
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{novel.chapters}</Text>
              <Text style={styles.statLabel}>فصل</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{novel.rating}</Text>
              <Text style={styles.statLabel}>تقييم</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{novel.status}</Text>
              <Text style={styles.statLabel}>الحالة</Text>
            </View>
          </View>

          {/* Action Buttons */}
          <View style={styles.actionRow}>
            <TouchableOpacity 
              style={[styles.libraryButton, inLib && styles.libraryButtonActive]}
              onPress={() => toggleLibrary(novel)}
            >
              <Ionicons 
                name={inLib ? "checkmark" : "add"} 
                size={24} 
                color={inLib ? "#fff" : "#fff"} 
              />
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.readButton}
              onPress={() => {
                const lastChapter = progress?.chapterId || 1;
                navigation.navigate('Reader', { novel, chapterId: lastChapter });
              }}
            >
              <Text style={styles.readButtonText}>
                {progress ? `تابع الفصل ${progress.chapterId}` : 'ابدأ القراءة'}
              </Text>
              <Ionicons name="book-outline" size={20} color="#000" style={{ marginLeft: 8 }} />
            </TouchableOpacity>
          </View>

          {/* Tabs */}
          <View style={styles.tabsContainer}>
            {renderTabButton('chapters', 'الفصول')}
            {renderTabButton('about', 'نظرة عامة')}
          </View>

          {activeTab === 'about' ? (
            <View style={styles.aboutSection}>
              <Text style={styles.sectionTitle}>القصة</Text>
              <Text style={styles.descriptionText}>{novel.description}</Text>
              
              <Text style={styles.sectionTitle}>التصنيفات</Text>
              <View style={styles.tagsRow}>
                {novel.tags.map((tag, index) => (
                  <View key={index} style={styles.tag}>
                    <Text style={styles.tagText}>{tag}</Text>
                  </View>
                ))}
              </View>
            </View>
          ) : (
            <View style={styles.chaptersList}>
               <View style={styles.chaptersHeader}>
                 <Text style={styles.chaptersCount}>{chaptersList.length} فصل</Text>
                 <Ionicons name="filter" size={18} color="#666" />
               </View>
               {chaptersList.map(item => (
                 <View key={item.id}>
                    {renderChapterItem({ item })}
                 </View>
               ))}
            </View>
          )}
        </View>
      </Animated.ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0,0,0,0.95)',
    zIndex: 90,
    borderBottomWidth: 1,
    borderBottomColor: '#1A1A1A',
  },
  headerSafe: {
    paddingVertical: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  floatingControls: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 100,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    pointerEvents: 'box-none',
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
  },
  coverContainer: {
    height: height * 0.55,
    width: '100%',
  },
  coverImage: {
    width: '100%',
    height: '100%',
  },
  coverGradient: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '40%',
  },
  contentContainer: {
    marginTop: -40,
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    marginBottom: 8,
  },
  author: {
    fontSize: 16,
    color: '#888',
    textAlign: 'center',
    marginBottom: 25,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30,
    backgroundColor: '#111',
    paddingVertical: 15,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#222',
  },
  statItem: {
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  statValue: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  statLabel: {
    color: '#666',
    fontSize: 12,
    marginTop: 4,
  },
  statDivider: {
    width: 1,
    height: 30,
    backgroundColor: '#333',
  },
  actionRow: {
    flexDirection: 'row',
    gap: 15,
    marginBottom: 30,
  },
  readButton: {
    flex: 1,
    height: 56,
    backgroundColor: '#fff',
    borderRadius: 28,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  readButtonText: {
    color: '#000',
    fontSize: 18,
    fontWeight: 'bold',
  },
  libraryButton: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#1A1A1A',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#333',
  },
  libraryButtonActive: {
    backgroundColor: '#4a7cc7',
    borderColor: '#4a7cc7',
  },
  tabsContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#1A1A1A',
    marginBottom: 20,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 15,
    alignItems: 'center',
  },
  tabButtonActive: {
    borderBottomWidth: 2,
    borderBottomColor: '#fff',
  },
  tabText: {
    fontSize: 16,
    color: '#666',
    fontWeight: '500',
  },
  tabTextActive: {
    color: '#fff',
    fontWeight: 'bold',
  },
  aboutSection: {
    paddingBottom: 20,
  },
  sectionTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
    textAlign: 'right',
    marginTop: 10,
  },
  descriptionText: {
    color: '#ccc',
    fontSize: 16,
    lineHeight: 26,
    textAlign: 'right',
    marginBottom: 25,
  },
  tagsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-end',
    gap: 10,
  },
  tag: {
    backgroundColor: '#1A1A1A',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#333',
  },
  tagText: {
    color: '#ccc',
    fontSize: 14,
  },
  chaptersList: {
    paddingBottom: 20,
  },
  chaptersHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
    paddingHorizontal: 5,
  },
  chaptersCount: {
    color: '#888',
    fontSize: 14,
  },
  chapterItem: {
    flexDirection: 'row-reverse',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#1A1A1A',
    alignItems: 'center',
  },
  chapterContent: {
    flex: 1,
    marginLeft: 15,
  },
  chapterTitle: {
    color: '#fff',
    fontSize: 16,
    textAlign: 'right',
    marginBottom: 4,
  },
  chapterTitleRead: {
    color: '#666',
  },
  chapterDate: {
    color: '#444',
    fontSize: 12,
    textAlign: 'right',
  },
  chapterLeft: {
    paddingLeft: 10,
  },
});
