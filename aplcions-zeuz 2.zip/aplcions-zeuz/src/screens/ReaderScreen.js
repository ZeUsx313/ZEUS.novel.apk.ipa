
import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Modal,
  Alert
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useApp } from '../context/AppContext';

const { width, height } = Dimensions.get('window');

// Helper to generate content that looks slightly different per chapter
const getChapterContent = (novelTitle, chapterId) => {
  return `
في هذا الفصل ${chapterId} من رواية "${novelTitle}"، تتصاعد الأحداث بشكل غير متوقع.

في أعماق جبال السحاب الأرجواني، حيث تتلاقى السماء والأرض في رقصة أبدية من الضباب والغموض، وقف بطلنا يراقب الأفق الممتد أمامه. كانت رياح الجبال الباردة تعصف بشعره، بينما تلمع عيناه الحادتان بإصرار لا يُقهر.

"لقد مر وقت طويل منذ الفصل ${chapterId - 1}،" همس لنفسه، وهو يشعر بطاقة الكي تتدفق في عروقه.

تذكر اليوم الذي دُمرت فيه عشيرته. كان لا يزال طفلاً صغيراً حينها. لكنه أقسم يومها، أقسم على دماء والده، أنه سيعود أقوى.

رفع يده نحو السماء، وبدأت هالة ذهبية تحيط بجسده. الطاقة التي اكتسبها كانت تتجاوز أي شيء حققه أي مزارع في هذه القارة.

"العشائر الخمس الكبرى،" قال بصوت هادئ لكنه يحمل وعداً بالعاصفة القادمة، "استعدوا... الفصل ${chapterId + 1} سيكون نهايتكم."

في تلك اللحظة، انشق الضباب المحيط بالجبل، وظهرت صورة سيف ضخم من الطاقة النقية في السماء.

... (بقية المحتوى للفصل ${chapterId} يملأ الصفحة لغرض التجربة) ...

نزل من قمة الجبل بخطوات ثابتة. كل خطوة كانت تترك أثراً من الطاقة الذهبية على الأرض. وجهته: مدينة السحاب الزمردي، حيث ستُعقد بطولة فنون القتال الكبرى.

ولكن ما لم يكن يعلمه، أن قوى أعظم بكثير كانت تراقبه من الظلام...
`;
};

export default function ReaderScreen({ route, navigation }) {
  const { novel, chapterId = 1 } = route.params;
  const { readerSettings, updateReaderSettings, saveReadingProgress } = useApp();
  
  const [content, setContent] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current; // Start hidden by default for immersion

  // Load Settings from Context
  const { fontSize, brightness, bgColor } = readerSettings;

  useEffect(() => {
    // Load content for specific chapter
    setContent(getChapterContent(novel.title, chapterId));
    
    // Save progress
    saveReadingProgress(novel, chapterId);
  }, [chapterId, novel]);

  const toggleMenu = () => {
    const toValue = showMenu ? 0 : 1;
    setShowMenu(!showMenu);
    Animated.timing(fadeAnim, {
      toValue,
      duration: 300,
      useNativeDriver: true,
    }).start();
  };

  const handleNextChapter = () => {
    if (chapterId < (novel.chapters || 100)) {
      navigation.push('Reader', { novel, chapterId: chapterId + 1 });
    } else {
      Alert.alert('تنبيه', 'لقد وصلت لنهاية الفصول المتاحة حالياً.');
    }
  };

  const handlePrevChapter = () => {
    if (chapterId > 1) {
      navigation.goBack();
    }
  };

  const bgColors = [
    { id: 1, color: '#000000', name: 'أسود نقي' },
    { id: 2, color: '#0a0a0a', name: 'أسود داكن' },
    { id: 3, color: '#1a1a1a', name: 'رمادي داكن' },
    { id: 4, color: '#2d2d2d', name: 'رمادي' },
  ];

  const brightnessLevels = [
    { id: 0, name: 'منخفض', icon: 'sunny-outline' },
    { id: 1, name: 'متوسط', icon: 'sunny' },
    { id: 2, name: 'عالي', icon: 'sunny' },
  ];

  return (
    <View style={[styles.container, { backgroundColor: bgColor }]}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* Top Menu Bar */}
        <Animated.View style={[styles.topBar, { opacity: fadeAnim, pointerEvents: showMenu ? 'auto' : 'none' }]}>
          <View style={styles.topBarContent}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => navigation.goBack()}
            >
              <Ionicons name="arrow-forward" size={24} color="#fff" />
            </TouchableOpacity>
            
            <View style={styles.chapterInfo}>
              <Text style={styles.chapterTitle} numberOfLines={1}>
                الفصل {chapterId}
              </Text>
              <Text style={styles.novelTitleSmall} numberOfLines={1}>
                {novel.title}
              </Text>
            </View>

            <TouchableOpacity
              style={styles.settingsButton}
              onPress={() => setShowSettings(true)}
            >
              <Ionicons name="settings-outline" size={24} color="#fff" />
            </TouchableOpacity>
          </View>
        </Animated.View>

        {/* Content */}
        <TouchableOpacity
          activeOpacity={1}
          onPress={toggleMenu}
          style={styles.contentContainer}
        >
          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.scrollContent}
          >
            <Text style={[styles.chapterTitleLarge, { fontSize: fontSize + 6, color: brightness === 0 ? '#888' : '#fff' }]}>
              الفصل {chapterId}
            </Text>
            
            <Text style={[styles.content, { fontSize, color: brightness === 0 ? '#666' : '#ccc' }]}>
              {content}
            </Text>

            <View style={styles.chapterNavigation}>
              <TouchableOpacity 
                style={[styles.navButton, chapterId === 1 && styles.navButtonDisabled]} 
                onPress={handlePrevChapter}
                disabled={chapterId === 1}
              >
                <Ionicons name="chevron-forward" size={20} color={chapterId === 1 ? "#444" : "#fff"} />
                <Text style={[styles.navButtonText, { color: chapterId === 1 ? '#444' : '#fff' }]}>
                  الفصل السابق
                </Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={[styles.navButton, styles.navButtonActive]}
                onPress={handleNextChapter}
              >
                <Text style={styles.navButtonTextActive}>الفصل التالي</Text>
                <Ionicons name="chevron-back" size={20} color="#fff" />
              </TouchableOpacity>
            </View>
          </ScrollView>
        </TouchableOpacity>

        {/* Bottom Menu Bar */}
        <Animated.View style={[styles.bottomBar, { opacity: fadeAnim, pointerEvents: showMenu ? 'auto' : 'none' }]}>
          <View style={styles.bottomBarContent}>
            <TouchableOpacity style={styles.bottomButton}>
              <Ionicons name="list-outline" size={24} color="#fff" />
              <Text style={styles.bottomButtonText}>الفصول</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.bottomButton} onPress={() => Alert.alert('تم', 'تمت إضافة علامة مرجعية')}>
              <Ionicons name="bookmark-outline" size={24} color="#fff" />
              <Text style={styles.bottomButtonText}>علامة</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.bottomButton}>
              <Ionicons name="chatbubble-outline" size={24} color="#fff" />
              <Text style={styles.bottomButtonText}>تعليقات</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.bottomButton}>
              <Ionicons name="share-outline" size={24} color="#fff" />
              <Text style={styles.bottomButtonText}>مشاركة</Text>
            </TouchableOpacity>
          </View>
        </Animated.View>
      </SafeAreaView>

      {/* Settings Modal */}
      <Modal
        visible={showSettings}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowSettings(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.settingsModal}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>إعدادات القراءة</Text>
              <TouchableOpacity onPress={() => setShowSettings(false)}>
                <Ionicons name="close" size={28} color="#fff" />
              </TouchableOpacity>
            </View>

            {/* Font Size */}
            <View style={styles.settingSection}>
              <Text style={styles.settingLabel}>حجم الخط</Text>
              <View style={styles.fontSizeButtons}>
                <TouchableOpacity
                  style={styles.fontButton}
                  onPress={() => updateReaderSettings({ fontSize: Math.max(14, fontSize - 2) })}
                >
                  <Text style={styles.fontButtonText}>أ-</Text>
                </TouchableOpacity>
                <Text style={styles.fontSizeValue}>{fontSize}</Text>
                <TouchableOpacity
                  style={styles.fontButton}
                  onPress={() => updateReaderSettings({ fontSize: Math.min(32, fontSize + 2) })}
                >
                  <Text style={styles.fontButtonText}>أ+</Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* Brightness */}
            <View style={styles.settingSection}>
              <Text style={styles.settingLabel}>السطوع (محاكاة)</Text>
              <View style={styles.brightnessButtons}>
                {brightnessLevels.map((level) => (
                  <TouchableOpacity
                    key={level.id}
                    style={[
                      styles.brightnessButton,
                      brightness === level.id && styles.brightnessButtonActive
                    ]}
                    onPress={() => updateReaderSettings({ brightness: level.id })}
                  >
                    <Ionicons 
                      name={level.icon} 
                      size={24} 
                      color={brightness === level.id ? '#4a7cc7' : '#666'} 
                    />
                    <Text style={[
                      styles.brightnessText,
                      brightness === level.id && styles.brightnessTextActive
                    ]}>
                      {level.name}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Background Color */}
            <View style={styles.settingSection}>
              <Text style={styles.settingLabel}>لون الخلفية</Text>
              <View style={styles.colorButtons}>
                {bgColors.map((item) => (
                  <TouchableOpacity
                    key={item.id}
                    style={[
                      styles.colorButton,
                      { backgroundColor: item.color },
                      bgColor === item.color && styles.colorButtonActive
                    ]}
                    onPress={() => updateReaderSettings({ bgColor: item.color })}
                  >
                    {bgColor === item.color && (
                      <Ionicons name="checkmark" size={24} color="#4a7cc7" />
                    )}
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  topBar: {
    position: 'absolute',
    top: 40, // adjust based on safe area
    left: 0,
    right: 0,
    backgroundColor: 'rgba(15, 15, 15, 0.95)',
    borderBottomWidth: 1,
    borderBottomColor: '#2a2a2a',
    zIndex: 10,
  },
  topBarContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  backButton: {
    marginLeft: 15,
  },
  chapterInfo: {
    flex: 1,
    alignItems: 'flex-end',
  },
  chapterTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
  },
  novelTitleSmall: {
    fontSize: 13,
    color: '#666',
  },
  settingsButton: {
    marginRight: 15,
  },
  contentContainer: {
    flex: 1,
    marginTop: 0,
  },
  scrollContent: {
    padding: 20,
    paddingTop: 60, // Space for top bar
    paddingBottom: 100,
  },
  chapterTitleLarge: {
    fontWeight: 'bold',
    marginBottom: 25,
    textAlign: 'right',
  },
  content: {
    lineHeight: 36, // Better reading height
    textAlign: 'right',
    marginBottom: 40,
  },
  chapterNavigation: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 40,
    gap: 15,
  },
  navButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#1a1a1a',
    paddingVertical: 14,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: '#2a2a2a',
  },
  navButtonDisabled: {
    opacity: 0.5,
  },
  navButtonActive: {
    backgroundColor: '#4a7cc7',
    borderColor: '#4a7cc7',
  },
  navButtonText: {
    fontSize: 15,
    fontWeight: '600',
    marginHorizontal: 8,
  },
  navButtonTextActive: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600',
    marginLeft: 8,
  },
  bottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(15, 15, 15, 0.95)',
    borderTopWidth: 1,
    borderTopColor: '#2a2a2a',
    zIndex: 10,
  },
  bottomBarContent: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 12,
    paddingBottom: 20,
  },
  bottomButton: {
    alignItems: 'center',
  },
  bottomButtonText: {
    color: '#aaa',
    fontSize: 12,
    marginTop: 4,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
    justifyContent: 'flex-end',
  },
  settingsModal: {
    backgroundColor: '#1a1a1a',
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    padding: 25,
    paddingBottom: 40,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 25,
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
  },
  settingSection: {
    marginBottom: 25,
  },
  settingLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 12,
    textAlign: 'right',
  },
  fontSizeButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 20,
  },
  fontButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#2a2a2a',
    alignItems: 'center',
    justifyContent: 'center',
  },
  fontButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  fontSizeValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#4a7cc7',
    minWidth: 40,
    textAlign: 'center',
  },
  brightnessButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  brightnessButton: {
    flex: 1,
    backgroundColor: '#2a2a2a',
    padding: 15,
    borderRadius: 15,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#2a2a2a',
  },
  brightnessButtonActive: {
    borderColor: '#4a7cc7',
    backgroundColor: 'rgba(74, 124, 199, 0.1)',
  },
  brightnessText: {
    color: '#666',
    fontSize: 12,
    marginTop: 5,
    fontWeight: '600',
  },
  brightnessTextActive: {
    color: '#4a7cc7',
  },
  colorButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 10,
  },
  colorButton: {
    width: 60,
    height: 60,
    borderRadius: 30,
    borderWidth: 3,
    borderColor: '#2a2a2a',
    alignItems: 'center',
    justifyContent: 'center',
  },
  colorButtonActive: {
    borderColor: '#4a7cc7',
    borderWidth: 4,
  },
});
