
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  FlatList,
  Dimensions
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useApp } from '../context/AppContext';

export default function LibraryScreen({ navigation }) {
  const { library, readingHistory } = useApp();
  const [activeTab, setActiveTab] = useState('reading');

  // Filter novels based on tabs (Mocking status logic since we don't have 'status' in all items perfectly)
  const getFilteredData = () => {
    if (activeTab === 'favorites') {
       // Just showing all for demo, or filter by a 'favorite' flag if implemented
       return library; 
    }
    if (activeTab === 'completed') {
      return library.filter(n => n.status === 'مكتملة');
    }
    // Reading
    return library;
  };

  const data = getFilteredData();

  const renderItem = ({ item }) => {
    const progress = readingHistory[item.id];
    
    return (
      <TouchableOpacity 
        style={styles.bookItem}
        onPress={() => navigation.navigate('NovelDetail', { novel: item })}
      >
        <Image source={{ uri: item.cover }} style={styles.bookCover} />
        <View style={styles.bookInfo}>
          <Text style={styles.bookTitle} numberOfLines={2}>{item.title}</Text>
          <Text style={styles.bookAuthor}>{item.author}</Text>
          
          {progress ? (
            <View style={styles.progressContainer}>
               <Text style={styles.progressText}>وصلت للفصل {progress.chapterId}</Text>
               <View style={styles.progressBarBg}>
                  <View style={[styles.progressBarFill, { width: `${progress.percentage}%` }]} />
               </View>
            </View>
          ) : (
            <Text style={styles.statusText}>{item.status}</Text>
          )}
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>📚 مكتبتي</Text>
      </View>

      {/* Tabs */}
      <View style={styles.tabs}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'reading' && styles.tabActive]}
          onPress={() => setActiveTab('reading')}
        >
          <Text style={[styles.tabText, activeTab === 'reading' && styles.tabTextActive]}>
            قيد القراءة
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'completed' && styles.tabActive]}
          onPress={() => setActiveTab('completed')}
        >
          <Text style={[styles.tabText, activeTab === 'completed' && styles.tabTextActive]}>
            مكتملة
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'favorites' && styles.tabActive]}
          onPress={() => setActiveTab('favorites')}
        >
          <Text style={[styles.tabText, activeTab === 'favorites' && styles.tabTextActive]}>
            المفضلة
          </Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      {data.length > 0 ? (
        <FlatList
          data={data}
          renderItem={renderItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
        />
      ) : (
        <View style={styles.emptyStateContainer}>
          <LinearGradient
            colors={['#1a1a1a', '#0f0f0f']}
            style={styles.emptyCard}
          >
            <View style={styles.iconContainer}>
              <LinearGradient
                colors={['#4a7cc7', '#4ac794']}
                style={styles.iconGradient}
              >
                <Ionicons name="book-outline" size={50} color="#fff" />
              </LinearGradient>
            </View>
            
            <Text style={styles.emptyTitle}>المكتبة فارغة</Text>
            <Text style={styles.emptyDescription}>
              لم تقم بإضافة أي روايات في هذا القسم بعد
            </Text>
            
            <TouchableOpacity
              style={styles.exploreButton}
              onPress={() => navigation.navigate('Home')}
            >
              <LinearGradient
                colors={['#4a7cc7', '#4ac794']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.exploreGradient}
              >
                <Ionicons name="compass" size={20} color="#fff" />
                <Text style={styles.exploreButtonText}>استكشف الروايات</Text>
              </LinearGradient>
            </TouchableOpacity>
          </LinearGradient>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#1a1a1a',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'right',
  },
  tabs: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingTop: 20,
    gap: 10,
    marginBottom: 10,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 15,
    backgroundColor: '#1a1a1a',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#2a2a2a',
  },
  tabActive: {
    backgroundColor: '#4a7cc7',
    borderColor: '#4a7cc7',
  },
  tabText: {
    color: '#666',
    fontSize: 14,
    fontWeight: '600',
  },
  tabTextActive: {
    color: '#fff',
  },
  listContainer: {
    padding: 20,
  },
  bookItem: {
    flexDirection: 'row-reverse',
    backgroundColor: '#111',
    borderRadius: 12,
    padding: 12,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#222',
  },
  bookCover: {
    width: 70,
    height: 100,
    borderRadius: 8,
    marginLeft: 15,
  },
  bookInfo: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-end',
  },
  bookTitle: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'right',
  },
  bookAuthor: {
    color: '#888',
    fontSize: 13,
    marginBottom: 10,
    textAlign: 'right',
  },
  progressContainer: {
    width: '100%',
    alignItems: 'flex-end',
  },
  progressText: {
    color: '#4a7cc7',
    fontSize: 12,
    marginBottom: 5,
  },
  progressBarBg: {
    width: '100%',
    height: 4,
    backgroundColor: '#333',
    borderRadius: 2,
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: '#4a7cc7',
    borderRadius: 2,
  },
  statusText: {
    color: '#666',
    fontSize: 12,
  },
  emptyStateContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 30,
  },
  emptyCard: {
    width: '100%',
    borderRadius: 25,
    padding: 40,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#2a2a2a',
  },
  iconContainer: {
    marginBottom: 25,
  },
  iconGradient: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
    textAlign: 'center',
  },
  emptyDescription: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 30,
    lineHeight: 24,
  },
  exploreButton: {
    borderRadius: 18,
    overflow: 'hidden',
    width: '100%',
  },
  exploreGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
  },
  exploreButtonText: {
    color: '#fff',
    fontSize: 17,
    fontWeight: 'bold',
    marginRight: 8,
  },
});
