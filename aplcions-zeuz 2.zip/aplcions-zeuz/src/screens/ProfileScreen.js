
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  StatusBar,
  Alert
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useApp } from '../context/AppContext';

export default function ProfileScreen() {
  const { user, library, logout } = useApp();
  const [notifications, setNotifications] = React.useState(true);

  const completedCount = library.filter(n => n.status === 'مكتملة').length;
  const readingCount = library.length; // Approximate for now

  const handleLogout = () => {
    Alert.alert(
      'تسجيل الخروج',
      'هل أنت متأكد من تسجيل الخروج؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        { text: 'خروج', style: 'destructive', onPress: logout }
      ]
    );
  };

  const MenuItem = ({ icon, title, hasArrow = true, onPress, rightElement, color = "#fff" }) => (
    <TouchableOpacity style={styles.menuItem} onPress={onPress} activeOpacity={0.7}>
      {hasArrow && !rightElement && (
        <Ionicons name="chevron-back" size={18} color="#444" />
      )}
      {rightElement}
      <View style={styles.menuTextContainer}>
        <Text style={[styles.menuTitle, { color }]}>{title}</Text>
      </View>
      <View style={styles.iconBox}>
        <Ionicons name={icon} size={20} color={color === "#fff" ? "#fff" : color} />
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <SafeAreaView style={styles.safeArea}>
        
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>الملف الشخصي</Text>
        </View>

        <ScrollView showsVerticalScrollIndicator={false}>
          
          {/* User Info */}
          <View style={styles.profileSection}>
            <View style={styles.avatarContainer}>
              <Ionicons name="person" size={40} color="#fff" />
            </View>
            <Text style={styles.userName}>{user?.name || 'زائر'}</Text>
            <Text style={styles.userEmail}>{user?.email || ''}</Text>
            <TouchableOpacity style={styles.editButton}>
              <Text style={styles.editButtonText}>تعديل البيانات</Text>
            </TouchableOpacity>
          </View>

          {/* Stats Bar */}
          <View style={styles.statsContainer}>
            <View style={styles.statBox}>
              <Text style={styles.statNumber}>{completedCount}</Text>
              <Text style={styles.statLabel}>مكتملة</Text>
            </View>
            <View style={styles.divider} />
            <View style={styles.statBox}>
              <Text style={styles.statNumber}>{readingCount}</Text>
              <Text style={styles.statLabel}>في المكتبة</Text>
            </View>
            <View style={styles.divider} />
            <View style={styles.statBox}>
              <Text style={styles.statNumber}>0</Text>
              <Text style={styles.statLabel}>تعليقات</Text>
            </View>
          </View>

          {/* Settings Section */}
          <View style={styles.sectionContainer}>
            <Text style={styles.sectionHeader}>التطبيق</Text>
            
            <View style={styles.card}>
              <MenuItem 
                icon="notifications-outline" 
                title="الإشعارات" 
                hasArrow={false}
                rightElement={
                  <Switch
                    value={notifications}
                    onValueChange={setNotifications}
                    trackColor={{ false: '#222', true: '#fff' }}
                    thumbColor={notifications ? '#000' : '#444'}
                  />
                }
              />
              <View style={styles.separator} />
              <MenuItem icon="moon-outline" title="المظهر" rightElement={<Text style={styles.valueText}>داكن</Text>} />
              <View style={styles.separator} />
              <MenuItem icon="globe-outline" title="اللغة" rightElement={<Text style={styles.valueText}>العربية</Text>} />
            </View>
          </View>

          {/* Account Section */}
          <View style={styles.sectionContainer}>
            <Text style={styles.sectionHeader}>الحساب والدعم</Text>
            
            <View style={styles.card}>
              <MenuItem icon="wallet-outline" title="الاشتراكات" />
              <View style={styles.separator} />
              <MenuItem icon="help-circle-outline" title="المساعدة والدعم" />
              <View style={styles.separator} />
              <MenuItem icon="document-text-outline" title="الشروط والخصوصية" />
            </View>
          </View>

          {/* Logout */}
          <View style={styles.sectionContainer}>
            <View style={[styles.card, { borderColor: '#331111' }]}>
              <MenuItem 
                icon="log-out-outline" 
                title="تسجيل الخروج" 
                color="#ff4444"
                hasArrow={false}
                onPress={handleLogout}
              />
            </View>
          </View>

          <Text style={styles.version}>v1.1.0 Beta</Text>
          <View style={{ height: 40 }} />

        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  safeArea: {
    flex: 1,
  },
  header: {
    padding: 20,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#111',
  },
  headerTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  profileSection: {
    alignItems: 'center',
    paddingVertical: 30,
  },
  avatarContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#1A1A1A',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#333',
  },
  userName: {
    color: '#fff',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  userEmail: {
    color: '#666',
    fontSize: 14,
    marginBottom: 20,
  },
  editButton: {
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#333',
    backgroundColor: '#0a0a0a',
  },
  editButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '500',
  },
  statsContainer: {
    flexDirection: 'row',
    marginHorizontal: 20,
    backgroundColor: '#111',
    borderRadius: 16,
    padding: 20,
    marginBottom: 30,
    borderWidth: 1,
    borderColor: '#222',
  },
  statBox: {
    flex: 1,
    alignItems: 'center',
  },
  divider: {
    width: 1,
    backgroundColor: '#333',
  },
  statNumber: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#666',
    fontSize: 12,
  },
  sectionContainer: {
    marginBottom: 25,
    paddingHorizontal: 20,
  },
  sectionHeader: {
    color: '#666',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 10,
    textAlign: 'right',
    marginRight: 5,
  },
  card: {
    backgroundColor: '#111',
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#222',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  menuTextContainer: {
    flex: 1,
    alignItems: 'flex-end',
    marginRight: 15,
  },
  menuTitle: {
    fontSize: 16,
    fontWeight: '500',
  },
  iconBox: {
    width: 32,
    alignItems: 'center',
  },
  valueText: {
    color: '#666',
    fontSize: 14,
  },
  separator: {
    height: 1,
    backgroundColor: '#1A1A1A',
    marginLeft: 16,
  },
  version: {
    textAlign: 'center',
    color: '#333',
    fontSize: 12,
    marginBottom: 20,
  },
});
