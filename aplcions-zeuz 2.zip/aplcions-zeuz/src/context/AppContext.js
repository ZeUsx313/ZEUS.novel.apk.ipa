
import React, { createContext, useState, useEffect, useContext } from 'react';
import { novelsData } from '../data/novelsData';

const AppContext = createContext();

export const AppProvider = ({ children }) => {
  // --- User State ---
  const [user, setUser] = useState(null); // null means logged out
  
  // --- Data State ---
  const [library, setLibrary] = useState([]); // List of novel objects
  const [readingHistory, setReadingHistory] = useState({}); // { novelId: { chapterId: 1, progress: 0.5, lastReadAt: Date } }
  const [favorites, setFavorites] = useState([]);
  
  // --- Settings State ---
  const [readerSettings, setReaderSettings] = useState({
    fontSize: 18,
    brightness: 2, // 0-2 index
    bgColor: '#0a0a0a',
    fontFamily: 'System'
  });

  // --- Actions ---

  const login = (email, password) => {
    // Mock Login
    setUser({
      name: 'مستخدم تجريبي',
      email: email,
      avatar: null
    });
  };

  const signup = (name, email, password) => {
    // Mock Signup
    setUser({
      name: name,
      email: email,
      avatar: null
    });
  };

  const logout = () => {
    setUser(null);
  };

  const toggleLibrary = (novel) => {
    setLibrary(current => {
      const exists = current.find(n => n.id === novel.id);
      if (exists) {
        return current.filter(n => n.id !== novel.id);
      } else {
        return [...current, { ...novel, dateAdded: new Date() }];
      }
    });
  };

  const isInLibrary = (novelId) => {
    return library.some(n => n.id === novelId);
  };

  const saveReadingProgress = (novel, chapterId) => {
    setReadingHistory(prev => ({
      ...prev,
      [novel.id]: {
        novel: novel,
        chapterId: chapterId,
        lastReadAt: new Date(),
        // Calculate rough percentage (mock calculation based on 1000 chapters avg if not present)
        percentage: Math.min(100, Math.round((chapterId / (novel.chapters || 1000)) * 100))
      }
    }));

    // If reading, auto add to library if logic dictates, but usually user adds manually.
    // Let's ensure it's in "Continue Reading" list implicitly via history.
  };

  const getLastRead = () => {
    // Return the most recently read novel
    const histories = Object.values(readingHistory);
    if (histories.length === 0) return null;
    return histories.sort((a, b) => b.lastReadAt - a.lastReadAt)[0];
  };

  const updateReaderSettings = (newSettings) => {
    setReaderSettings(prev => ({ ...prev, ...newSettings }));
  };

  return (
    <AppContext.Provider value={{
      user,
      login,
      signup,
      logout,
      library,
      toggleLibrary,
      isInLibrary,
      readingHistory,
      saveReadingProgress,
      getLastRead,
      readerSettings,
      updateReaderSettings
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => useContext(AppContext);
